
window.plugins.CallNumber.callNumber(
    function(result){// success phone called do nothing
    },
    function(result){ //failed phone called, show some message
    },
    <number to be dial>,
    false);
