-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2021 at 04:58 AM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `frontend_labtest`
--

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` varchar(6) NOT NULL,
  `email` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `email`) VALUES
('1002', 'dmurphy@classicmodelcars.com'),
('1056', 'mpatterso@classicmodelcars.com'),
('1076', 'jfirrelli@classicmodelcars.com'),
('1088', 'wpatterson@classicmodelcars.com'),
('1102', 'gbondur@classicmodelcars.com'),
('1143', 'abow@classicmodelcars.com'),
('1165', 'ljennings@classicmodelcars.com'),
('1166', 'lthompson@classicmodelcars.com'),
('1188', 'jfirrelli@classicmodelcars.com'),
('1216', 'spatterson@classicmodelcars.com'),
('1286', 'ftseng@classicmodelcars.com'),
('1323', 'gvanauf@classicmodelcars.com'),
('1337', 'lbondur@classicmodelcars.com'),
('1370', 'ghernande@classicmodelcars.com'),
('1401', 'pcastillo@classicmodelcars.com'),
('1501', 'lbott@classicmodelcars.com'),
('1504', 'bjones@classicmodelcars.com'),
('1611', 'afixter@classicmodelcars.com'),
('1612', 'pmarsh@classicmodelcars.com'),
('1619', 'tking@classicmodelcars.com'),
('1621', 'mnishi@classicmodelcars.com'),
('1625', 'ykato@classicmodelcars.com'),
('1702', 'mgerard@classicmodelcars.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
