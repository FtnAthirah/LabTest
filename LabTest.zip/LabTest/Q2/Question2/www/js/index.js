var link1 = crossroads.addRoute("/staff", function () {
    $(".navbar-collapse li").removeClass("active");
    $(".navbar-collapse li a[href='#staff']").parent().addClass("active");
    var email = sessionStorage.ttoken;
    var datalist = "email=" + email;
    $.ajax({
            type: "post",
            url: "http://www.skimtech.my/ClassicModels/GetStaff",
            data: datalist,
            cache: false,
            success: function (mydata) {
                    var myData = JSON.parse(mydata);
                    //alert(mydata);
                    var lastIndex = myData.length - 1;
                    var htmlText = "";
                    if (myData[lastIndex].status === 1) {
                            for (var i = 0; i < lastIndex; i++) {
                                    htmlText = htmlText + "<tr><td>" + myData[i].id
                                            + "</td><td><a href='#viewstaff/" + myData[i].id + "'>"+ myData[i].email
                                           

                                            + "</a></td></tr>";
                            }
                            $("#tblStaff tbody").html(htmlText);
                    }
            },
            error: function () {
                    console.log("ajax error!");
                    alert("Please contact admin!");
            }
    });
    $("#divHome").hide();
    $("#divStaff").show();
    $("#divStaffById").show();
});



